<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Pages Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"terms-of-service" => "Términos de servicio",
	"privacy" => "Privacidad",
	"about" => "Acerca de nosotros",
	"how-it-works" => "Cómo funciona",
	"cookies" => "Política de cookies",
);
