<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| SEO Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"slogan" => "Soporte a los creadores de contenido", // New on v4.0
	"description" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut tortor rutrum massa efficitur tincidunt vel nec lacus. Curabitur porta aliquet diam, eu gravida neque lacinia.",
	"keywords" => "donaciones,soporte,creadores,sponzy,suscripción,contenido",
);
