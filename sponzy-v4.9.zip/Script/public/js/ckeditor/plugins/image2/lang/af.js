/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'af', {
	alt: 'Alternatiewe teks',
	btnUpload: 'Stuur na bediener',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Afbeelding informasie',
	lockRatio: 'Vaste proporsie',
	menu: 'Afbeelding eienskappe',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Herstel grootte',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Afbeelding eienskappe',
	uploadTab: 'Oplaai',
	urlMissing: 'Die URL na die afbeelding ontbreek.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
