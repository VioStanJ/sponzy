/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'cs', {
	pathName: 'objekt média',
	title: 'Vložení médií',
	button: 'Vložit médium',
	unsupportedUrlGiven: 'Zadaná URL není podporována.',
	unsupportedUrl: 'URL {url} není podporována ',
	fetchingFailedGiven: 'Pro zadanou adresu URL nelze získat obsah.',
	fetchingFailed: 'Nelze získat obsah na {url}.',
	fetchingOne: 'Získávání odpovědí oEmbed...',
	fetchingMany: 'Získávání odpovědí oEmbed. {current} z {max} hotovo...'
} );
