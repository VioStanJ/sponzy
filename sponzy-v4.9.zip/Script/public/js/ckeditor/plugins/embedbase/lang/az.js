/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'az', {
	pathName: 'Multimedia obyektləri',
	title: 'Multimedia obyektlərin quraşdırılması',
	button: 'Multimedia obyekti quraşdır',
	unsupportedUrlGiven: 'Daxil etdiyiniz linki dəstəklənmir',
	unsupportedUrl: '{url} linki quraşdırıla bilməz',
	fetchingFailedGiven: 'Daxil etdiyiniz linkdən gələn məlumat yanlışdır',
	fetchingFailed: '{url} linkdən gələn məlumat yanlışdır',
	fetchingOne: 'oEmbed tərəfindən cavabın yoxlanması...',
	fetchingMany: 'oEmbed tərəfindən cavabların yoxlanması, {max}-dan {current} yerinə yetirilib...'
} );
